package com.sixamtech.sixvalley

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
